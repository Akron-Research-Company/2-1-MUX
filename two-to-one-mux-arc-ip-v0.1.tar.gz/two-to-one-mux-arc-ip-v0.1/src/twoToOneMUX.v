`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: Akron Research Company
// Engineer: Bennett Miller
// 
// Create Date: 09/06/2026 12:51:54 AM
// Design Name: TwoToOneMultiplexor
// Module Name: twoToOneMUX
// Project Name: TwoToOneMultiplexor
// Target Devices: Any
// Tool Versions: Any
// Description: Simple Two to One Multiplexor / Multiplexer
// 
// Dependencies: None
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// Experimentation Done on Diligent Basys 3
//////////////////////////////////////////////////////////////////////////////////


module twoToOneMUX(a, b, s, o);
    input a, b, s;
    output o;
    
    assign o = (s) ? b : a;
    
endmodule
